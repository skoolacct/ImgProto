//(c) A+ Computer Science
// www.apluscompsci.com

//print/println example
//esacpe sequence example

public class Escape1
{
	public static void main(String args[])
	{
		System.out.println("aplus\\compsci/");
		System.out.println("apluscompsci\"");
		System.out.println("apluscomp\nsci");
	}	
}