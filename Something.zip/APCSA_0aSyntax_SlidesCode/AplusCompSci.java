//(c) A+ Computer Science
// www.apluscompsci.com

//bare bones class example

public class AplusCompSci
{
   public static void main(String args[])
	{
		System.out.print("Aplus Comp Sci!");
	}
}