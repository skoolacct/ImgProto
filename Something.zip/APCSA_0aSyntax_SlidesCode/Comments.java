//(c) A+ Computer Science
// www.apluscompsci.com

//comment example

public class Comments
{
	public static void main(String args[])
	{		
		//single line comment
		//printf will be used more later
		//System.out.println( "this is a single line comment" );
			
		/*
		 this
		 is
		 a 
		 block
		 comment
		 
		 System.out.println( "this is a block comment" );
		*/	
	}
}