//(c) A+ Computer Science
// www.apluscompsci.com

//print/println example

public class Basic
{
	public static void main(String args[])
	{
		System.out.print("aplus compsci");
		System.out.println();

		System.out.print("aplus compsci");
		System.out.print("aplus compsci");
		System.out.println();

		System.out.println("aplus compsci");
		System.out.println();

		System.out.println("aplus compsci");
		System.out.println("aplus compsci");
		System.out.println();
	}
}