//(c) A+ Computer Science
// www.apluscompsci.com

//more advance print and println stuff

public class StringOut
{
	public static void main(String args[])
	{
		System.out.println( 7 + 8 + 9 );
		System.out.println( 7 + " " + 8 + 9 );
		System.out.println( 7 + 8 + " " + 9 );	
			
		//how did it do that?
		//System.out.println( 1+ 7 + 8 + " " + 9 * 3 );	
			
		//brain teaser example	
		//System.out.println( 7 + 8 + " " + 9 + 3 - 4);				
	}
}